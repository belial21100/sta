import { create } from 'zustand';
import { Resource, GameState, Building, City, BuildingUpgrade } from '../types/game';
import { supabase } from '../lib/supabase';
import { useAuthStore } from './authStore';

const SAVE_INTERVAL = 10000; // Save to database every 10 seconds
const UPDATE_INTERVAL = 1000; // Update resources every second

const INITIAL_STATE: GameState = {
  resources: {
    naquadah: 0,
    deuterium: 0,
    trinium: 0,
    people: 0
  },
  buildings: [
    {
      id: 'naquadah_mine',
      name: 'Naquadah Mine',
      level: 1,
      cost: { naquadah: 200, deuterium: 100, trinium: 50, people: 0 },
      production: { naquadah: 10, deuterium: 0, trinium: 0, people: 0 },
      description: 'Deep underground facility extracting precious Naquadah, the foundation of advanced Stargate technology.'
    },
    {
      id: 'deuterium_synthesizer',
      name: 'Deuterium Synthesizer',
      level: 1,
      cost: { naquadah: 150, deuterium: 50, trinium: 25, people: 0 },
      production: { naquadah: 0, deuterium: 5, trinium: 0, people: 0 },
      description: 'Advanced facility that extracts and processes Deuterium for powering ships and weapons.'
    },
    {
      id: 'trinium_processor',
      name: 'Trinium Processor',
      level: 1,
      cost: { naquadah: 300, deuterium: 150, trinium: 75, people: 0 },
      production: { naquadah: 0, deuterium: 0, trinium: 3, people: 0 },
      description: 'Specialized facility that refines raw Trinium ore into its super-strong alloy form.'
    },
    {
      id: 'zpm_facility',
      name: 'ZPM Research Facility',
      level: 1,
      cost: { naquadah: 500, deuterium: 250, trinium: 100, people: 0 },
      production: { naquadah: 15, deuterium: 8, trinium: 4, people: 0 },
      description: 'Advanced Ancient facility studying Zero Point Modules, providing bonus resources from subspace energy.'
    },
    {
      id: 'gate_room',
      name: 'Gate Room',
      level: 1,
      cost: { naquadah: 1000, deuterium: 500, trinium: 200, people: 0 },
      production: { naquadah: 20, deuterium: 10, trinium: 5, people: 0 },
      description: 'The heart of your base, housing a Stargate. Higher levels enable more efficient resource trading through the gate network.'
    },
    {
      id: 'ancient_outpost',
      name: 'Ancient Outpost',
      level: 1,
      cost: { naquadah: 2000, deuterium: 1000, trinium: 400, people: 0 },
      production: { naquadah: 30, deuterium: 15, trinium: 8, people: 0 },
      description: 'A discovered Ancient facility with advanced technology, providing significant resource generation.'
    },
    {
      id: 'asgard_core',
      name: 'Asgard Core',
      level: 1,
      cost: { naquadah: 3000, deuterium: 1500, trinium: 600, people: 0 },
      production: { naquadah: 40, deuterium: 20, trinium: 10, people: 0 },
      description: 'Repository of Asgard knowledge and technology, significantly boosting all resource production.'
    },
    {
      id: 'house',
      name: 'House',
      level: 1,
      cost: { naquadah: 100, deuterium: 50, trinium: 25, people: 0 },
      production: { naquadah: 0, deuterium: 0, trinium: 0, people: 100 },
      description: 'Residential building that provides housing for your population.'
    }
  ],
  lastUpdate: Date.now(),
  currentCity: null,
  cities: [],
  initialized: false,
  error: null
};

interface GameStore extends GameState {
  updateResources: () => void;
  upgradeBuilding: (buildingId: string) => Promise<{ success: boolean; message?: string }>;
  fetchCities: () => Promise<void>;
  setCurrentCity: (city: City) => void;
  saveResources: () => Promise<void>;
  retryInitialization: () => Promise<void>;
  checkBuildingUpgrades: () => Promise<void>;
}

export const useGameStore = create<GameStore>((set, get) => ({
  ...INITIAL_STATE,
  
  fetchCities: async () => {
    const { user, profile } = useAuthStore.getState();
    if (!user || !profile) {
      set({ error: 'No authenticated user found or profile not loaded' });
      return;
    }

    try {
      // First, ensure the profile exists in the database
      const { data: profiles, error: profileError } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', user.id);

      if (profileError) {
        console.error('Error checking profile:', profileError);
        set({ error: 'Failed to verify profile' });
        return;
      }

      if (!profiles || profiles.length === 0) {
        set({ error: 'Profile not found in database' });
        return;
      }

      // Subscribe to real-time updates for the cities table
      const citiesSubscription = supabase
        .channel('cities_channel')
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'cities',
            filter: `user_id=eq.${user.id}`
          },
          (payload) => {
            const updatedCity = payload.new as City;
            get().setCurrentCity(updatedCity);
          }
        )
        .subscribe();

      // Now fetch cities with automatic resource updates
      const { data: cities, error: citiesError } = await supabase
        .from('cities')
        .select('*')
        .eq('user_id', user.id);

      if (citiesError) {
        console.error('Error fetching cities:', citiesError);
        set({ error: 'Failed to fetch cities' });
        return;
      }

      if (!cities || cities.length === 0) {
        // Create initial city if none exists
        const { data: newCity, error: createError } = await supabase
          .from('cities')
          .insert([
            {
              user_id: user.id,
              name: 'Main Base',
              naquadah: 1000,
              deuterium: 500,
              trinium: 200,
              people: 1000,
              last_update: new Date().toISOString()
            }
          ])
          .select()
          .single();

        if (createError) {
          console.error('Error creating initial city:', createError);
          set({ error: 'Failed to create initial city' });
          return;
        }

        set({
          cities: [newCity],
          currentCity: newCity,
          resources: {
            naquadah: newCity.naquadah,
            deuterium: newCity.deuterium,
            trinium: newCity.trinium,
            people: newCity.people
          },
          initialized: true,
          error: null,
          lastUpdate: Date.now()
        });
      } else {
        set({
          cities,
          currentCity: cities[0],
          resources: {
            naquadah: cities[0].naquadah,
            deuterium: cities[0].deuterium,
            trinium: cities[0].trinium,
            people: cities[0].people
          },
          initialized: true,
          error: null,
          lastUpdate: Date.now()
        });
      }

      // Start checking for building upgrades
      setInterval(() => {
        get().checkBuildingUpgrades();
      }, 5000); // Check every 5 seconds

    } catch (error) {
      console.error('Error in fetchCities:', error);
      set({ error: 'Failed to initialize game data' });
    }
  },

  checkBuildingUpgrades: async () => {
    const { currentCity } = get();
    if (!currentCity) return;

    try {
      // Fetch active upgrades
      const { data: upgrades, error } = await supabase
        .from('building_upgrades')
        .select('*')
        .eq('city_id', currentCity.id)
        .eq('completed', false)
        .lt('end_time', new Date().toISOString());

      if (error) {
        console.error('Error checking building upgrades:', error);
        return;
      }

      if (!upgrades || upgrades.length === 0) return;

      // Fetch the latest city data to get current building levels
      const { data: city, error: cityError } = await supabase
        .from('cities')
        .select('*')
        .eq('id', currentCity.id)
        .single();

      if (cityError || !city) {
        console.error('Error fetching city data:', cityError);
        return;
      }

      // Update local state with new building levels
      const updatedBuildings = get().buildings.map(building => {
        const cityBuilding = city.buildings[building.id];
        if (cityBuilding) {
          return {
            ...building,
            level: cityBuilding.level,
            isUpgrading: false,
            upgradeEndsAt: undefined
          };
        }
        return building;
      });

      set({
        buildings: updatedBuildings,
        currentCity: city,
        resources: {
          naquadah: city.naquadah,
          deuterium: city.deuterium,
          trinium: city.trinium,
          people: city.people
        }
      });
    } catch (error) {
      console.error('Error in checkBuildingUpgrades:', error);
    }
  },

  retryInitialization: async () => {
    set({ error: null, initialized: false });
    await get().fetchCities();
  },

  setCurrentCity: (city: City) => {
    set({
      currentCity: city,
      resources: {
        naquadah: city.naquadah,
        deuterium: city.deuterium,
        trinium: city.trinium,
        people: city.people
      },
      lastUpdate: Date.now()
    });
  },

  saveResources: async () => {
    const { currentCity, resources } = get();
    if (!currentCity) return;

    try {
      const { error } = await supabase
        .from('cities')
        .update({
          naquadah: Math.floor(resources.naquadah),
          deuterium: Math.floor(resources.deuterium),
          trinium: Math.floor(resources.trinium),
          people: Math.floor(resources.people),
          updated_at: new Date().toISOString(),
          last_update: new Date().toISOString()
        })
        .eq('id', currentCity.id);

      if (error) {
        console.error('Error saving resources:', error);
        throw error;
      }
    } catch (error) {
      console.error('Failed to save resources:', error);
    }
  },
  
  updateResources: () => {
    const currentTime = Date.now();
    const timeDiff = (currentTime - get().lastUpdate) / 1000; // Convert to seconds
    
    set(state => {
      const newResources = { ...state.resources };
      
      state.buildings.forEach(building => {
        newResources.naquadah += building.production.naquadah * timeDiff;
        newResources.deuterium += building.production.deuterium * timeDiff;
        newResources.trinium += building.production.trinium * timeDiff;
        newResources.people += building.production.people * timeDiff;
      });
      
      return {
        resources: newResources,
        lastUpdate: currentTime
      };
    });
  },
  
  upgradeBuilding: async (buildingId: string) => {
    const state = get();
    const { currentCity } = state;
    if (!currentCity) return { success: false, message: 'No city selected' };

    try {
      // Check if building is already being upgraded
      const { data: activeUpgrades, error: checkError } = await supabase
        .from('building_upgrades')
        .select('*')
        .eq('city_id', currentCity.id)
        .eq('building_id', buildingId)
        .eq('completed', false);

      if (checkError) {
        console.error('Error checking active upgrades:', checkError);
        return { success: false, message: 'Failed to check building status' };
      }

      if (activeUpgrades && activeUpgrades.length > 0) {
        return { success: false, message: 'This building is already being upgraded' };
      }

      // Start the building upgrade in the database
      const { data, error } = await supabase
        .rpc('start_building_upgrade', {
          p_city_id: currentCity.id,
          p_building_id: buildingId
        });

      if (error) {
        console.error('Error starting building upgrade:', error);
        return { success: false, message: 'Failed to start upgrade' };
      }

      if (!data.success) {
        console.error('Failed to start upgrade:', data.message);
        return { success: false, message: data.message };
      }

      // Update local state
      const upgrade = data.upgrade;
      const updatedBuildings = state.buildings.map(b =>
        b.id === buildingId
          ? {
              ...b,
              isUpgrading: true,
              upgradeEndsAt: upgrade.end_time
            }
          : b
      );

      set({
        buildings: updatedBuildings,
        resources: {
          ...state.resources,
          naquadah: currentCity.naquadah,
          deuterium: currentCity.deuterium,
          trinium: currentCity.trinium,
          people: currentCity.people
        }
      });

      return { success: true };
    } catch (error) {
      console.error('Error in upgradeBuilding:', error);
      return { success: false, message: 'An unexpected error occurred' };
    }
  }
}));

// Set up intervals for resource updates and saving
if (typeof window !== 'undefined') {
  // Update resources every second
  setInterval(() => {
    const store = useGameStore.getState();
    if (store.initialized && store.currentCity) {
      store.updateResources();
    }
  }, UPDATE_INTERVAL);

  // Save to database every 10 seconds
  setInterval(() => {
    const store = useGameStore.getState();
    if (store.initialized && store.currentCity) {
      store.saveResources();
    }
  }, SAVE_INTERVAL);
}