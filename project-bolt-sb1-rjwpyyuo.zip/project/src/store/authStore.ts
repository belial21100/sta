import { create } from 'zustand';
import { supabase } from '../lib/supabase';

interface Profile {
  username: string;
  email: string;
}

interface AuthState {
  user: any | null;
  profile: Profile | null;
  loading: boolean;
  initialized: boolean;
  lastRegistrationAttempt: number;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, username?: string) => Promise<void>;
  signOut: () => Promise<void>;
  fetchProfile: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  profile: null,
  loading: true,
  initialized: false,
  lastRegistrationAttempt: 0,

  fetchProfile: async () => {
    const { user } = get();
    if (!user) return;

    try {
      // First ensure profile exists
      const { error: ensureError } = await supabase
        .rpc('ensure_profile_exists', {
          user_id: user.id,
          user_email: user.email
        });

      if (ensureError) {
        console.error('Error ensuring profile exists:', ensureError);
        return;
      }

      // Then fetch the profile
      const { data: profiles, error } = await supabase
        .from('profiles')
        .select('username, email')
        .eq('id', user.id);

      if (error) {
        console.error('Error fetching profile:', error);
        return;
      }

      // Get the first profile or create a default one
      const profile = profiles?.[0] || {
        username: user.email?.split('@')[0] || 'User',
        email: user.email || ''
      };

      set({ profile });
    } catch (error) {
      console.error('Error in fetchProfile:', error);
    }
  },

  signIn: async (email: string, password: string) => {
    try {
      set({ loading: true });
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.toLowerCase(),
        password,
      });
      
      if (error) throw error;
      
      set({ user: data.user });
      await get().fetchProfile();
    } catch (error) {
      throw error;
    } finally {
      set({ loading: false });
    }
  },

  signUp: async (email: string, password: string, username?: string) => {
    const currentTime = Date.now();
    const lastAttempt = get().lastRegistrationAttempt;
    const timeSinceLastAttempt = currentTime - lastAttempt;
    
    if (timeSinceLastAttempt < 300000) {
      throw new Error(`Please wait ${Math.ceil((300000 - timeSinceLastAttempt) / 1000)} seconds before trying again`);
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      throw new Error('Please enter a valid email address');
    }

    try {
      set({ loading: true, lastRegistrationAttempt: currentTime });

      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: email.toLowerCase(),
        password,
        options: {
          data: {
            username: username
          }
        }
      });
      
      if (authError) {
        if (authError.status === 429) {
          throw new Error('Too many registration attempts. Please try again in 5 minutes.');
        }
        throw authError;
      }
      
      if (!authData.user) {
        throw new Error('Failed to create user account');
      }

      const { data, error: profileError } = await supabase
        .rpc('register_user', {
          user_id: authData.user.id,
          user_email: email.toLowerCase(),
          username: username,
          password: password
        });

      if (profileError || !data?.success) {
        await supabase.auth.signOut();
        throw new Error(data?.message || 'Failed to create user profile');
      }

      set({ user: authData.user });
      await get().fetchProfile();
    } catch (error: any) {
      await supabase.auth.signOut();
      
      if (error.status === 429) {
        throw new Error('Too many registration attempts. Please try again in 5 minutes.');
      } else if (error.message.includes('User already registered')) {
        throw new Error('This email is already registered. Please try logging in instead.');
      } else {
        throw error;
      }
    } finally {
      set({ loading: false });
    }
  },

  signOut: async () => {
    try {
      set({ loading: true });
      
      // Clear state first to prevent UI issues
      set({
        user: null,
        profile: null,
        lastRegistrationAttempt: 0
      });

      // Attempt to sign out from Supabase
      try {
        await supabase.auth.signOut();
      } catch (error) {
        console.warn('Supabase sign out failed:', error);
        // Continue with local cleanup even if Supabase sign out fails
      }

      // Force a clean reload to ensure all state is cleared
      window.location.href = '/login';
    } catch (error) {
      console.error('Error in signOut:', error);
      // Still redirect even if there's an error
      window.location.href = '/login';
    } finally {
      set({ loading: false });
    }
  }
}));

// Initialize auth state from stored session
const initializeAuth = async () => {
  try {
    // Check for existing session
    const { data: { session }, error } = await supabase.auth.getSession();
    
    if (error) {
      throw error;
    }

    if (session?.user) {
      useAuthStore.setState({ user: session.user });
      await useAuthStore.getState().fetchProfile();
    }
  } catch (error) {
    console.error('Error initializing auth:', error);
  } finally {
    useAuthStore.setState({ loading: false, initialized: true });
  }
};

// Listen for auth state changes
supabase.auth.onAuthStateChange(async (event, session) => {
  const store = useAuthStore.getState();
  
  if (!store.initialized) {
    return; // Wait for initialization
  }

  if (event === 'SIGNED_OUT') {
    useAuthStore.setState({
      user: null,
      profile: null,
      loading: false,
      lastRegistrationAttempt: 0
    });
  } else if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
    if (session?.user) {
      useAuthStore.setState({ user: session.user, loading: false });
      await store.fetchProfile();
    }
  }
});

// Initialize auth state when the store is created
initializeAuth();