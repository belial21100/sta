import React from 'react';
import { BuildingQueue } from '../components/BuildingQueue';
import { ResourceSummary } from '../components/ResourceSummary';

export const Home: React.FC = () => {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-white mb-6">Command Center Overview</h2>
        <ResourceSummary />
      </div>
      
      <div>
        <h2 className="text-xl font-semibold mb-4">Active Construction</h2>
        <BuildingQueue />
      </div>
    </div>
  );
};