import React from 'react';
import { useGameStore } from '../store/gameStore';
import { TrendingUp, Clock } from 'lucide-react';

export const ResourceSummary: React.FC = () => {
  const { resources, buildings } = useGameStore();

  const totalProduction = buildings.reduce(
    (acc, building) => ({
      naquadah: acc.naquadah + building.production.naquadah,
      deuterium: acc.deuterium + building.production.deuterium,
      trinium: acc.trinium + building.production.trinium,
      people: acc.people + building.production.people,
    }),
    { naquadah: 0, deuterium: 0, trinium: 0, people: 0 }
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="bg-gray-800 rounded-lg p-6">
        <h3 className="text-lg font-medium text-gray-200 mb-4">Current Resources</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-purple-300">Naquadah</div>
            <div className="text-2xl font-bold text-purple-400">
              {Math.floor(resources.naquadah)}
            </div>
          </div>
          <div>
            <div className="text-blue-300">Deuterium</div>
            <div className="text-2xl font-bold text-blue-400">
              {Math.floor(resources.deuterium)}
            </div>
          </div>
          <div>
            <div className="text-green-300">Trinium</div>
            <div className="text-2xl font-bold text-green-400">
              {Math.floor(resources.trinium)}
            </div>
          </div>
          <div>
            <div className="text-yellow-300">Population</div>
            <div className="text-2xl font-bold text-yellow-400">
              {Math.floor(resources.people)}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg p-6">
        <h3 className="text-lg font-medium text-gray-200 mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          Production per Second
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-purple-300">Naquadah</div>
            <div className="text-xl font-semibold text-purple-400">
              +{totalProduction.naquadah.toFixed(1)}
            </div>
          </div>
          <div>
            <div className="text-blue-300">Deuterium</div>
            <div className="text-xl font-semibold text-blue-400">
              +{totalProduction.deuterium.toFixed(1)}
            </div>
          </div>
          <div>
            <div className="text-green-300">Trinium</div>
            <div className="text-xl font-semibold text-green-400">
              +{totalProduction.trinium.toFixed(1)}
            </div>
          </div>
          <div>
            <div className="text-yellow-300">Population</div>
            <div className="text-xl font-semibold text-yellow-400">
              +{totalProduction.people.toFixed(1)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};