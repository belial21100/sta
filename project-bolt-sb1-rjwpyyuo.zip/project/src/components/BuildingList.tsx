import React from 'react';
import { Building } from '../types/game';
import { useGameStore } from '../store/gameStore';
import { Clock } from 'lucide-react';

const BUILDING_IMAGES: Record<string, string> = {
  naquadah_mine: 'https://images.unsplash.com/photo-1518623001395-125242310d0c?auto=format&fit=crop&q=80&w=400&h=300',
  deuterium_synthesizer: 'https://images.unsplash.com/photo-1581093458791-9f3c3250a8b5?auto=format&fit=crop&q=80&w=400&h=300',
  trinium_processor: 'https://images.unsplash.com/photo-1581093458791-9f3c3250a8b5?auto=format&fit=crop&q=80&w=400&h=300',
  zpm_facility: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=400&h=300',
  gate_room: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&q=80&w=400&h=300',
  ancient_outpost: 'https://images.unsplash.com/photo-1446776858070-70c3d5ed6758?auto=format&fit=crop&q=80&w=400&h=300',
  asgard_core: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&q=80&w=400&h=300',
  house: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&q=80&w=400&h=300',
};

export const BuildingList: React.FC = () => {
  const { buildings, upgradeBuilding } = useGameStore();
  const [error, setError] = React.useState<string | null>(null);

  const handleUpgrade = async (buildingId: string) => {
    setError(null);
    const result = await upgradeBuilding(buildingId);
    if (!result.success && result.message) {
      setError(result.message);
    }
  };

  return (
    <div>
      {error && (
        <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-lg mb-6">
          {error}
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        {buildings.map(building => (
          <BuildingCard
            key={building.id}
            building={building}
            onUpgrade={() => handleUpgrade(building.id)}
          />
        ))}
      </div>
    </div>
  );
};

const BuildingCard: React.FC<{
  building: Building;
  onUpgrade: () => void;
}> = ({ building, onUpgrade }) => {
  const [timeLeft, setTimeLeft] = React.useState<string>('');

  React.useEffect(() => {
    if (!building.isUpgrading || !building.upgradeEndsAt) return;

    const updateTimer = () => {
      const now = new Date().getTime();
      const endTime = new Date(building.upgradeEndsAt!).getTime();
      const diff = endTime - now;

      if (diff <= 0) {
        setTimeLeft('');
        return;
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft(`${hours}h ${minutes}m ${seconds}s`);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);

    return () => clearInterval(interval);
  }, [building.isUpgrading, building.upgradeEndsAt]);

  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden transform transition-all duration-300 hover:scale-[1.02] hover:shadow-xl">
      <div className="h-48 relative">
        <img
          src={BUILDING_IMAGES[building.id]}
          alt={building.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <h3 className="text-xl font-bold text-white">{building.name}</h3>
          <p className="text-gray-300 text-sm">Level {building.level}</p>
        </div>
      </div>

      <div className="p-4">
        <p className="text-gray-400 text-sm">{building.description}</p>
        
        <div className="mt-4 space-y-3">
          <div className="bg-gray-700/50 rounded-lg p-3">
            <h4 className="text-gray-300 text-sm font-medium mb-2">Production per second:</h4>
            <div className="grid grid-cols-2 gap-2 text-sm">
              {building.production.naquadah > 0 && (
                <div className="text-purple-300">Naquadah: +{building.production.naquadah}</div>
              )}
              {building.production.deuterium > 0 && (
                <div className="text-blue-300">Deuterium: +{building.production.deuterium}</div>
              )}
              {building.production.trinium > 0 && (
                <div className="text-green-300">Trinium: +{building.production.trinium}</div>
              )}
              {building.production.people > 0 && (
                <div className="text-yellow-300">People: +{building.production.people}</div>
              )}
            </div>
          </div>

          {building.isUpgrading ? (
            <div className="bg-blue-900/50 p-4 rounded-lg">
              <div className="flex items-center gap-2 text-blue-300">
                <Clock className="w-5 h-5 animate-spin" />
                <span className="font-medium">Upgrading...</span>
              </div>
              {timeLeft && (
                <p className="text-sm text-blue-200 mt-2">
                  Time remaining: {timeLeft}
                </p>
              )}
            </div>
          ) : (
            <button
              onClick={onUpgrade}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white px-4 py-3 rounded-lg transition-colors duration-200 flex flex-col items-center gap-1"
            >
              <span className="font-medium">Upgrade to Level {building.level + 1}</span>
              <div className="text-xs text-blue-200 flex gap-2">
                <span>{building.cost.naquadah} Naquadah</span>
                <span>{building.cost.deuterium} Deuterium</span>
                <span>{building.cost.trinium} Trinium</span>
              </div>
              {building.upgradeTime && (
                <div className="text-xs text-blue-200 mt-1">
                  Time: {Math.floor(building.upgradeTime / 3600)}h {Math.floor((building.upgradeTime % 3600) / 60)}m
                </div>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};