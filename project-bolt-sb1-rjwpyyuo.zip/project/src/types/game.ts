export interface Resource {
  naquadah: number;
  deuterium: number;
  trinium: number;
  people: number;
}

export interface Building {
  id: string;
  name: string;
  level: number;
  cost: Resource;
  production: Resource;
  description: string;
  upgradeTime?: number; // in seconds
  isUpgrading?: boolean;
  upgradeEndsAt?: string;
}

export interface BuildingUpgrade {
  id: string;
  buildingId: string;
  fromLevel: number;
  toLevel: number;
  startTime: string;
  endTime: string;
  completed: boolean;
}

export interface City {
  id: string;
  name: string;
  naquadah: number;
  deuterium: number;
  trinium: number;
  people: number;
  created_at: string;
  updated_at: string;
  buildings: { [key: string]: Building };
  upgrades?: BuildingUpgrade[];
}

export interface GameState {
  resources: Resource;
  buildings: Building[];
  lastUpdate: number;
  currentCity: City | null;
  cities: City[];
  initialized: boolean;
  error: string | null;
}